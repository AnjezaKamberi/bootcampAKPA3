package bootcampAKPA3.seanca1;

//import bootcampAKPA3.ushtrime.KlasaA;
//import bootcampAKPA3.ushtrime.KlasaB;

// importo te gjitha tipet qe ndodhen brenda paketes bootcampAKPA3.ushtrime
//import bootcampAKPA3.ushtrime.*;

//importo te gjitha tipet qe ndodhen brenda paketes bootcampAKPA3.kontroll
//import bootcampAKPA3.kontroll.*;

public class Main {

	public static void main(String[] args) {
		System.out.print("Hello world!");
		System.out.println("Mire se erdhet ne bootcampin JAVA 2023-2024");
		System.out.print("ikubINFOACADEMY");
		// perdor KlasaA dhe KlasaB te paketes bootcampAKPA3.ushtrime
		bootcampAKPA3.ushtrime.KlasaA objektiKlasaA = new bootcampAKPA3.ushtrime.KlasaA();
		bootcampAKPA3.ushtrime.KlasaB objektiKlasaB = new bootcampAKPA3.ushtrime.KlasaB();

		// perdor KlasaA dhe KlasaB te paketes bootcampAKPA3.kontroll
		bootcampAKPA3.kontroll.KlasaA objektiKlasaAKontroll = new bootcampAKPA3.kontroll.KlasaA();
		bootcampAKPA3.kontroll.KlasaB objektiKlasaBKontroll = new bootcampAKPA3.kontroll.KlasaB();

	}
}
