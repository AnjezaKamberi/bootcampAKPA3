package bootcampAKPA3.seanca2;

public class OperatorRelacional {

	public static void main(String[] args) {

		int numer1 = 5;
		int numer2 = 6;

		System.out.println("Numer1 me i madh se numer2 " + (numer1 > numer2));
		System.out.println("Numer1 me i vogel se numer2 " + (numer1 < numer2));
		System.out.println("Numer1 me i madh ose baraz se numer2 " + (numer1 >= numer2));
		System.out.println("Numer1 me i vogel ose baraz se numer2 " + (numer1 <= numer2));
		System.out.println("Numer1 eshte i barabarte me numer2 " + (numer1 == numer2));
		System.out.println("Numer1 eshte i ndryshem nga numer2 " + (numer1 != numer2));
	}
}
