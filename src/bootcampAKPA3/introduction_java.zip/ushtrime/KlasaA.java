package bootcampAKPA3.ushtrime;

public class KlasaA {

}
