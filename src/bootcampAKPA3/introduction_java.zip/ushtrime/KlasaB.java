package bootcampAKPA3.ushtrime;

public class KlasaB {

}
