package bootcampAKPA3.kontroll;

public class KlasaA {

}
